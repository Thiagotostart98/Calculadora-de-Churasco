function calcular() {
    let homens = parseInt(document.getElementById('homens').value);
    let mulheres = parseInt(document.getElementById('mulheres').value);
    let criancas = parseInt(document.getElementById('criancas').value);

    let carneHomens= (homens * 500);
    let carneMulheres = (mulheres * 300) ;
    let carneCrianca = (criancas * 200);


    let frangoHomens = (homens * 200);
    let frangoMulheres = (mulheres * 200);
    let frangoCrianca = (criancas * 100);

    let linguicaHomens = (homens * 200);
    let linguicaMulheres = (mulheres * 200);
    let linguicaCriancas = (criancas * 200);

    let refrigeranteHomens = (homens * 300);
    let refrigeranteMulheres = (mulheres * 400);
    let refrigeranteCriancas = (criancas * 200);

    let cervejaHomens = (homens * 800);
    let cervejaMulheres = (mulheres * 500);;

    let resultado = `
        <h2>Resultado:</h2>
            <table border="1">
        <tr>
            <td></td>
            <td>Homens</td>
            <td>Mulheres</td>
            <td>Crianças</td>
        </tr>
        <tr>
            <td>Carne Bovina</td>
            <td>${carneHomens}g</td>
            <td>${carneMulheres}g</td>
            <td>${carneCrianca}g</td>
        </tr>
            <td>Frango</td>
            <td>${frangoHomens}g</td>
            <td>${frangoMulheres}g</td>
            <td>${frangoCrianca}g</td>

        </tr>
        <tr>
            <td>Linguiça</td>
            <td>${linguicaHomens}g</td>
            <td>${linguicaMulheres}g</td>
            <td>${linguicaCriancas}g</td>

        </tr>
        <tr>
            <td>Refrigerante</td>
            <td>${refrigeranteHomens}ml</td>
            <td>${refrigeranteMulheres}ml</td>
            <td>${refrigeranteCriancas}ml</td>

        </tr>
        <tr>
            <td>Cerveja</td>
            <td>${cervejaHomens}ml</td>
            <td>${cervejaMulheres}ml</td>
            <td>0ml</td>

        </tr>
    `;

    document.getElementById('resultado').innerHTML = resultado;
}
